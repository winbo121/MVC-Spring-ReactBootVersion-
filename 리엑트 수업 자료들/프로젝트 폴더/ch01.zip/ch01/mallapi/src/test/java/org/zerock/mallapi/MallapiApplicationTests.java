package org.zerock.mallapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
